**************
This document is setup to make sure the software and hardware configuration is setup correctly for the Lensless Imaging project.
Author: 	Shuyang Zhang
Date:	07/21/2021

**************
Table of contents:

1. Initial configuration of the Raspberry Pi 
2. Initial configuration of the Arduino
3. Initial configuration of the PC.

**************
1. Initial configuration of the Raspberry Pi:
	
	a. Setup the username and the password of your Pi. (By default, the username is pi, and the password is raspberry)
	b. Allow SSN connection.
	c. Check the IP address of your device. (by entering the command "ifconfig" in the Pi terminal, there should be one line saying the IP address)
	d. Install the gphoto 2 library. (The connection to the DSLR can be tested.....)
	e. Download the imageCapture.py to pi and save it under the following file path: /home/pi/Desktop/gphoto/imageCapture.py

**************
2. Initial configuration of the Arduino
	
	a. Solder the connection between the Arduino and the OLED panel.
	b. Download the Arduino2OLED.ino file on the PC and upload it to the Arduino. 

**************
3. Initial configuration of the PC:

	a. Softwares needed for the ethernet SSH connection: (all can be found on this website: https://www.chiark.greenend.org.uk/~sgtatham/putty/latest.html)
		- PuTTY			putty.exe (make sure the right version for your PC)
		- cmd line interface		plink.exe
		- SSH key generator	puttygen.exe (optional, not needed by default, can be used to increase connection secruity)
	
	b. Open the PC2Pi_CC.py file and make necessary changes to the Raspberry Pi ip address and password within the file. Steps to do that includes:
		- Check the ip address of your Raspberry Pi as mentioned above.
		- Check the username and password of the Raspberry Pi. 
		- Make corresponding correction to the commands in the OLED.py file.

	c. Open the PC2Pi_FT.py file and make necessary changes to the Raspberry Pi ip address and password within the file. Same as above.
	d. Open the OLED.sln file to execute the software or make changes to the main UI.
	