import sys
import subprocess

# filePath = sys.argv[1]

# Reminder: change the ip address and password to yours.
subprocess.run(["pscp.exe", "-P", "22", "-pw", "password",
                "pi@169.254.20.92:/home/pi/Desktop/gphoto/images/2021-02-26Pishots/*.CR2",
                "D:\ColemanLabMS\ImageFile"
                ], stdout=subprocess.PIPE)