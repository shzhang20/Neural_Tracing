import sys
import subprocess

# filePath = sys.argv[1]

# Reminder: change the ip address and password to yours.
subprocess.run(["plink", "-no-antispoof", "pi@169.254.20.92", "-pw", "password",
                "python3", "/home/pi/Desktop/gphoto/imageCapture.py"
                ], stdout=subprocess.PIPE)

