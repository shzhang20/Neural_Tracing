﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OLED
{
    public partial class Form3 : Form
    {
        public Form3(Form1 originForm, int[,] GridBoard)
        {
            InitializeComponent();
            this.originForm = originForm;
            this.GridBoard = GridBoard;
        }
        Form1 originForm = null;
        int[,] GridBoard = null;

        private void button1_Click(object sender, EventArgs e)
        {
            int[] quadrant = { 0, 0 };
            int[,] QuaBoard = this.convert(quadrant);
            Form2 frm2 = new Form2(originForm, QuaBoard, quadrant);
            frm2.ShowDialog();
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int[] quadrant = { 1, 0 };
            int[,] QuaBoard = this.convert(quadrant);
            Form2 frm2 = new Form2(originForm, QuaBoard, quadrant);
            frm2.ShowDialog();
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int[] quadrant = { 0, 1 };
            int[,] QuaBoard = this.convert(quadrant);
            Form2 frm2 = new Form2(originForm, QuaBoard, quadrant);
            frm2.ShowDialog();
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int[] quadrant = { 1, 1 };
            int [,] QuaBoard = this.convert(quadrant);
            Form2 frm2 = new Form2(originForm, QuaBoard, quadrant);
            frm2.ShowDialog();
            this.Close();
        }

        private int[,] convert(int[] quadrant)
        {
            int nX = this.GridBoard.GetLength(0)/2;
            int nY = this.GridBoard.GetLength(1)/2;
            int[,] QuaBoard = new int[nX, nY];

            for (int i = 0 + quadrant[0]*nX; i < nX*(quadrant[0]+1); i++)
            {
                for (int j = 0 + quadrant[1]*nY; j < nY * (quadrant[1] + 1); j++)
                {
                    QuaBoard[i - quadrant[0] * nX, j - quadrant[1] * nY] = this.GridBoard[i, j];
                }
            }
            return QuaBoard;
        }

    }   
}
