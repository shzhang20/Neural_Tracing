﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OLED
{
    public partial class Form1 : Form
    {
        static int nX = 128;
        static int nY = 96;
        
        int[,] GridBoard = new int[nX, nY];
        static int bmpMultiplier = 2;
        Bitmap bmp = new Bitmap(nX * bmpMultiplier, nY * bmpMultiplier);
        String ColorCode = "R";
        Color PaintColor = Color.Red;
        int ColorValue = 1;
        
        //Constructor
        public Form1()
        {
            InitializeComponent();
            serialPort1.Open();
            MapPanel.BackgroundImage = bmp;
            this.GridUpdate();
            redToolStripMenuItem.Checked = true;
        }

       

        //Methods
        private void RectPaint(int x_dim, int y_dim, int width, int height, Color color)
        {
            for (int w = 0; w < width; w++)
            {
                for (int h = 0; h < height; h++)
                {
                    this.bmp.SetPixel(x_dim * bmpMultiplier + w * bmpMultiplier, y_dim * bmpMultiplier + h * bmpMultiplier, color);
                }
            }
            MapPanel.Refresh();

        }

        private void GridUpdate()
        {
            for (int x = 0; x < nX; x++)
            {
                for (int y = 0; y < nY; y++)
                {
                    if (this.GridBoard[x, y] == 1)
                    {
                        this.bmp.SetPixel(x * bmpMultiplier, y * bmpMultiplier, Color.Red);
                    }

                    else if (this.GridBoard[x, y] == 2)
                    {
                        this.bmp.SetPixel(x * bmpMultiplier, y * bmpMultiplier, Color.Green);
                    }

                    else if (this.GridBoard[x, y] == 3)
                    {
                        this.bmp.SetPixel(x * bmpMultiplier, y * bmpMultiplier, Color.Blue);
                    }

                    else
                    {
                        this.bmp.SetPixel(x * bmpMultiplier, y * bmpMultiplier, Color.Black);
                    }

                }
            }
            MapPanel.Refresh();
        }

        public void DataSendingHandler(int[,] QuaBoard, int[] quadrant, List<String> commands)
        {
            for (int i = 0 + quadrant[0] * nX/2; i < (quadrant[0] + 1) * nX/2; i++)
            {
                for (int j = 0 + quadrant[1] * nY/2; j < (quadrant[1] + 1) * nY/2; j++)
                {
                    this.GridBoard[i, j] = QuaBoard[i - quadrant[0] * nX/2, j - quadrant[1] * nY/2];
                }
            }

            for (int c = 0; c < commands.Count; c++)
            {
                serialPort1.Write(commands[c]);
            }
            this.GridUpdate();
        }

        //EventHandlers
        private void Set_Click(object sender, EventArgs e)
        {
            int XStart = int.Parse(xValue.Text);
            int YStart = int.Parse(yValue.Text);
            int Width = int.Parse(width.Text);
            int Height = int.Parse(height.Text);

            for (int i = 0; i < Width; i++)
            {
                for (int j = 0; j < Height; j++)
                {
                    this.GridBoard[XStart + i, YStart + j] = ColorValue;
                }
            }


            serialPort1.Write("#R" + xValue.Text + yValue.Text + width.Text + height.Text + ColorCode + "\n");
            RectPaint(XStart, YStart, Width, Height, PaintColor);
        }

        private void ClearScr_Click(object sender, EventArgs e)
        {
            //Send Command to the Arduino to clear the screen of the OLED
            serialPort1.Write("#C\n");
            GridBoard = new int[nX, nY];
            this.GridUpdate();
        }

        private void ResTest_Click(object sender, EventArgs e)
        {
            //Send Command to the Arduino to do a ResTest of the OLED 
            serialPort1.Write("#T\n");
            int test_count = 1;
            for (int i = 0; i < nX; i = i + 2 * test_count)
            {
                for (int t = 0; t < test_count; t++)
                {
                    for (int j = 0; j < nY; j++)
                    {
                        GridBoard[i+t, j] = 1;
                    }
                }
                test_count = test_count + 1;
            }
            this.GridUpdate();
        }

        private void Preview_Click(object sender, EventArgs e)
        {
            Form3 frm3 = new Form3(this, this.GridBoard);
            frm3.ShowDialog();
        }

        private void redToolStripMenuItem_Click(object sender, EventArgs e)
        {
            greenToolStripMenuItem.Checked = false;
            blueToolStripMenuItem.Checked = false;
            redToolStripMenuItem.Checked = true;
            ColorCode = "R";                             
            ColorValue = 1;
            PaintColor = Color.Red;
        }

        private void greenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            greenToolStripMenuItem.Checked = true;
            blueToolStripMenuItem.Checked = false;
            redToolStripMenuItem.Checked = false;
            ColorCode = "G";
            ColorValue = 2;
            PaintColor = Color.Green;
        }

        private void blueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            greenToolStripMenuItem.Checked = false;
            blueToolStripMenuItem.Checked = true;
            redToolStripMenuItem.Checked = false;
            ColorCode = "B";
            ColorValue = 3;
            PaintColor = Color.Blue;
        }
    }
}
