﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Reflection;

namespace OLED
{
    public partial class Form2 : Form
    {
        //Color Section
        String ColorCode = "R";                             //Create the string that is going to be used at the end of arduino command as the ColorCode
        int ColorValue = 1;                                 //Store Color information as values within the 2D array; 1 = Red, 2 = Blue, 3 = Green.  
        


        public Form2(Form1 OriginalForm, int[,] QuaBoard, int[] quadrant) //Form 1 original form was deleted for testing
        {
            InitializeComponent();
            this.DoubleBuffered = false;
            this.OriginalForm = OriginalForm;
            this.QuaBoard = QuaBoard;
            this.quadrant = quadrant;
            this.ConfirmBtn.Visible = false;
            this.CancelBtn.Visible = false;


            typeof(Panel).InvokeMember("DoubleBuffered",
            BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.NonPublic,
            null, panel1, new object[] { true });

            this.commands = new List<string>();

            MouseStartPoint = new Point(-1, -1);
            MouseEndPoint = new Point(-1, -1);
            RectStartPoint = new Point(-1, -1);
            RectEndPoint = new Point(-1, -1);
            this.redToolStripMenuItem.Checked = true;
        }

        int[] quadrant = null;
        int[,] QuaBoard = null;
        Form1 OriginalForm = null;
        bool LMDown = false;
        bool RMDown = false;
        bool ConfirmState = false;

        static Point HoverPoint;                            // Record location information of the mouse
        static Point MouseStartPoint =  new Point(-1,-1);
        static Point MouseEndPoint = new Point(-1,-1);
        static Point RectStartPoint = new Point(-1, -1);
        static Point RectEndPoint = new Point(-1, -1);

        List<String> commands = null;                       

        static int RectWidth = 14;                          // Initialize the width of each tile
        static int RectHeight = 14;                         // Initialize the height of each tile
        static int gap = 2;                                 // Initialize the gap between the tiles
        static int BoardGap = 10;
        static int nX = 64;                                 // Number of pixels in the x-direction (Should be automatically inputted)*
        static int nY = 48;                                 // Number of pixels in the y-direction (Should be automatically inputted)*

        static int ButtonHeight = 100;

                                      



        // Create a function to handle the Painting of the grid
        private void PaintGrid(Graphics g)
        {
            

            // Use for loop to create 2D grid
            for (int i = 0; i < nX; i ++)
            {
                for (int j = 0; j < nY; j++)
                {
                    if (i == HoverPoint.X && j == HoverPoint.Y)
                    {
                        // When the tile of the grid is the one mouse hovers over, the tile turns to red
                        g.FillRectangle(Brushes.Blue, i * (RectWidth + gap) + BoardGap, j * (RectWidth + gap) + BoardGap, RectWidth, RectHeight);
                    }

                    else if (QuaBoard[i, j] == 1)
                    {
                        // When the tile of the grid is the one mouse hovers over, the tile turns to red
                        g.FillRectangle(Brushes.Red, i * (RectWidth + gap) + BoardGap, j * (RectWidth + gap) + BoardGap, RectWidth, RectHeight);
                    }

                    else if (QuaBoard[i, j] == 2)
                    {
                        // When the tile of the grid is the one mouse hovers over, the tile turns to red
                        g.FillRectangle(Brushes.Green, i * (RectWidth + gap) + BoardGap, j * (RectWidth + gap) + BoardGap, RectWidth, RectHeight);
                    }

                    else if (QuaBoard[i, j] == 3)
                    {
                        // When the tile of the grid is the one mouse hovers over, the tile turns to red
                        g.FillRectangle(Brushes.Blue, i * (RectWidth + gap) + BoardGap, j * (RectWidth + gap) + BoardGap, RectWidth, RectHeight);
                    }

                    else
                    {
                        // Each iteration will create a new box in new location with gap consideration
                        g.FillRectangle(Brushes.SandyBrown, i * (RectWidth + gap) + BoardGap, j * (RectWidth + gap) + BoardGap, RectWidth, RectHeight);
                    }
                }
            }

            //Handle Rectangle selection display
            if (MouseStartPoint.X != -1 && MouseEndPoint.X != -1)
            {
                
                for (int i = RectStartPoint.X; i <= RectEndPoint.X; i++)
                {
                    for (int j = RectStartPoint.Y; j <= RectEndPoint.Y; j++)
                    {
                        g.FillRectangle(Brushes.Gray, i * (RectWidth + gap) + BoardGap, j * (RectWidth + gap) + BoardGap, RectWidth, RectHeight);
                    }
                }
                

            }

        }


        private void UpdateSize()
        {

            this.Width = BoardGap * 2 + nY * (RectHeight + gap);
            this.Height = BoardGap * 2 + nY * (RectHeight + gap) + ButtonHeight;

            this.button1.Size = new Size(this.Width, ButtonHeight);
            this.button1.Location = new Point(0, gap * 2 + nY * (RectHeight + gap));
            
            this.panel1.Location = new Point(0, 0);
            this.panel1.Size = new Size(this.Width, this.Height - ButtonHeight);

            this.label1.Text = button1.Height.ToString();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            PaintGrid(e.Graphics);
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            // Retrieve the current xy coordinates of the mouse
            int x = ((e.X - BoardGap) / (RectWidth + gap));
            int y = ((e.Y - BoardGap) / (RectHeight + gap));

            if (x < nX && y < nY && x >= 0 && y >= 0)
            {
                if (ConfirmState == false)
                {
                    if (LMDown == true || RMDown == true)
                    {
                        MouseEndPoint.X = x;
                        MouseEndPoint.Y = y;

                        RectStartPoint.X = MouseStartPoint.X;
                        RectStartPoint.Y = MouseStartPoint.Y;
                        RectEndPoint.X = MouseEndPoint.X;
                        RectEndPoint.Y = MouseEndPoint.Y;

                        if (MouseEndPoint.X < MouseStartPoint.X)
                        {
                            RectEndPoint.X = MouseStartPoint.X;
                            RectStartPoint.X = MouseEndPoint.X;
                        }
                        if (MouseEndPoint.Y < MouseStartPoint.Y)
                        {
                            RectEndPoint.Y = MouseStartPoint.Y;
                            RectStartPoint.Y = MouseEndPoint.Y;
                        }
                    }
                }
                


                HoverPoint.X = x;
                HoverPoint.Y = y;
                this.XtextBox.Text = (x + quadrant[0] * nX).ToString();
                this.YtextBox.Text = (y + quadrant[1] * nY).ToString();

                this.panel1.Refresh();
            }

        }

        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
           
            ConfirmState = true;
            this.ConfirmBtn.Visible = true;
            this.CancelBtn.Visible = true;

            button1.Enabled = false;
            button2.Enabled = false;


        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            if (ConfirmState == false)
            {
                if (e.Button == MouseButtons.Left)
                {
                    // I want to enter the mode which I can select the tiles continously and hold the tiles in red
                    LMDown = true;
                    int x = ((e.X - BoardGap) / (RectWidth + gap));
                    int y = ((e.Y - BoardGap) / (RectHeight + gap));

                    MouseStartPoint.X = x;
                    MouseStartPoint.Y = y;

                    this.panel1.Refresh();
                }

                if (e.Button == MouseButtons.Right)
                {
                    // I want to enter the mode which I can select the tiles continously and hold the tiles in red
                    RMDown = true;
                    int x = ((e.X - BoardGap) / (RectWidth + gap));
                    int y = ((e.Y - BoardGap) / (RectHeight + gap));

                    MouseStartPoint.X = x;
                    MouseStartPoint.Y = y;

                    this.panel1.Refresh();
                }
            }

            


        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.OriginalForm.DataSendingHandler(this.QuaBoard, this.quadrant, this.commands);
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            QuaBoard = new int[nX, nY];
            this.Refresh();
        }

        private void ConfirmBtn_Click(object sender, EventArgs e)
        {
            String X = (RectStartPoint.X + quadrant[0] * 64).ToString("D3");
            String Y = (RectStartPoint.Y + quadrant[1] * 48).ToString("D3");
            String Width = (RectEndPoint.X - RectStartPoint.X + 1).ToString("D3");
            String Height = (RectEndPoint.Y - RectStartPoint.Y + 1).ToString("D3");

            if (LMDown == true)
            {
                for (int i = RectStartPoint.X; i <= RectEndPoint.X; i++)
                {
                    for (int j = RectStartPoint.Y; j <= RectEndPoint.Y; j++)
                    {
                        this.QuaBoard[i, j] = 1 * ColorValue;
                        this.commands.Add("#R" + X + Y + Width + Height + ColorCode + "\n");
                        LMDown = false;
                    }
                }
            }

            else if (RMDown == true)
            {
                for (int i = RectStartPoint.X; i <= RectEndPoint.X; i++)
                {
                    for (int j = RectStartPoint.Y; j <= RectEndPoint.Y; j++)
                    {
                        this.QuaBoard[i, j] = 0;
                        this.commands.Add("#R" + X + Y + Width + Height + "K" + "\n");
                        RMDown = false;
                    }
                }
            }

            button1.Enabled = true;
            button2.Enabled = true;
                
            this.ConfirmState = false;
            this.ConfirmBtn.Visible = false;
            this.CancelBtn.Visible = false;

            MouseStartPoint.X = -1;
            MouseEndPoint.Y = -1;
            RectStartPoint.X = -1;
            RectEndPoint.Y = -1;

            this.panel1.Refresh();
        }

        private void CancelBtn_Click(object sender, EventArgs e)
        {
            button1.Enabled = true;
            button2.Enabled = true;

            this.ConfirmState = false;
            this.ConfirmBtn.Visible = false;
            this.CancelBtn.Visible = false;

            MouseStartPoint.X = -1;
            MouseEndPoint.Y = -1;
            RectStartPoint.X = -1;
            RectEndPoint.Y = -1;

            this.panel1.Refresh();
        }


        private void redToolStripMenuItem_Click(object sender, EventArgs e)
        {
            greenToolStripMenuItem.Checked = false;
            blueToolStripMenuItem.Checked = false;
            redToolStripMenuItem.Checked = true;
            ColorCode = "R";                             
            ColorValue = 1;

        }

        private void greenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            greenToolStripMenuItem.Checked = true;
            blueToolStripMenuItem.Checked = false;
            redToolStripMenuItem.Checked = false;
            ColorCode = "G";                             
            ColorValue = 2;
        }

        private void blueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            greenToolStripMenuItem.Checked = false;
            blueToolStripMenuItem.Checked = true;
            redToolStripMenuItem.Checked = false;
            ColorCode = "B";                             
            ColorValue = 3;
        }
    }
}
