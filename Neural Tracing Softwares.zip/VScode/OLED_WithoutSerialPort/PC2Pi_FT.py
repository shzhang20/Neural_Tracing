import sys
import subprocess

folderSave = sys.argv[1]
date = sys.argv[2]

formatDate = date[:4] + "-" + date[4:6] + "-" + date[6:]
sourceFolder = "pi@169.254.20.92:/home/pi/Desktop/gphoto/images/{date}Pishots/*.CR2".format(date = formatDate)

# Reminder: change the ip address and password to yours.
subprocess.run(["pscp.exe", "-P", "22", "-pw", "password",
                sourceFolder, folderSave], stdout=subprocess.PIPE)