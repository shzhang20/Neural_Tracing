﻿namespace OLED
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PC2Pi_CC = new System.Windows.Forms.Button();
            this.CameraCtrlLabel = new System.Windows.Forms.Label();
            this.python_select = new System.Windows.Forms.Button();
            this.python_text = new System.Windows.Forms.TextBox();
            this.CC_text = new System.Windows.Forms.TextBox();
            this.CC_selector = new System.Windows.Forms.Button();
            this.FT_selector = new System.Windows.Forms.Button();
            this.FT_Text = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.PC2Pi_FT = new System.Windows.Forms.Button();
            this.shotsUp = new System.Windows.Forms.Button();
            this.shotsDown = new System.Windows.Forms.Button();
            this.totalShots_text = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.timeInterval_text = new System.Windows.Forms.TextBox();
            this.intervalDown = new System.Windows.Forms.Button();
            this.intervalUp = new System.Windows.Forms.Button();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.save_selector = new System.Windows.Forms.Button();
            this.Save_Text = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.yearText = new System.Windows.Forms.TextBox();
            this.yearDown = new System.Windows.Forms.Button();
            this.yearUp = new System.Windows.Forms.Button();
            this.monthText = new System.Windows.Forms.TextBox();
            this.monthDown = new System.Windows.Forms.Button();
            this.monthUp = new System.Windows.Forms.Button();
            this.dayText = new System.Windows.Forms.TextBox();
            this.dayDown = new System.Windows.Forms.Button();
            this.dayUp = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // PC2Pi_CC
            // 
            this.PC2Pi_CC.Font = new System.Drawing.Font("SimSun", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.PC2Pi_CC.Location = new System.Drawing.Point(119, 663);
            this.PC2Pi_CC.Name = "PC2Pi_CC";
            this.PC2Pi_CC.Size = new System.Drawing.Size(276, 91);
            this.PC2Pi_CC.TabIndex = 0;
            this.PC2Pi_CC.Text = "Start";
            this.PC2Pi_CC.UseVisualStyleBackColor = true;
            this.PC2Pi_CC.Click += new System.EventHandler(this.PC2Pi_CC_Click);
            // 
            // CameraCtrlLabel
            // 
            this.CameraCtrlLabel.AutoSize = true;
            this.CameraCtrlLabel.Font = new System.Drawing.Font("SimSun", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CameraCtrlLabel.Location = new System.Drawing.Point(112, 316);
            this.CameraCtrlLabel.Name = "CameraCtrlLabel";
            this.CameraCtrlLabel.Size = new System.Drawing.Size(297, 40);
            this.CameraCtrlLabel.TabIndex = 1;
            this.CameraCtrlLabel.Text = "Camera Control";
            // 
            // python_select
            // 
            this.python_select.Location = new System.Drawing.Point(119, 45);
            this.python_select.Name = "python_select";
            this.python_select.Size = new System.Drawing.Size(209, 55);
            this.python_select.TabIndex = 2;
            this.python_select.Text = "Select python directory";
            this.python_select.UseVisualStyleBackColor = true;
            this.python_select.Click += new System.EventHandler(this.python_select_Click);
            // 
            // python_text
            // 
            this.python_text.Location = new System.Drawing.Point(344, 62);
            this.python_text.Name = "python_text";
            this.python_text.Size = new System.Drawing.Size(627, 25);
            this.python_text.TabIndex = 3;
            // 
            // CC_text
            // 
            this.CC_text.Location = new System.Drawing.Point(344, 138);
            this.CC_text.Name = "CC_text";
            this.CC_text.Size = new System.Drawing.Size(627, 25);
            this.CC_text.TabIndex = 4;
            // 
            // CC_selector
            // 
            this.CC_selector.Location = new System.Drawing.Point(119, 121);
            this.CC_selector.Name = "CC_selector";
            this.CC_selector.Size = new System.Drawing.Size(209, 55);
            this.CC_selector.TabIndex = 5;
            this.CC_selector.Text = "Select PC2Pi_CC directory";
            this.CC_selector.UseVisualStyleBackColor = true;
            this.CC_selector.Click += new System.EventHandler(this.CC_selector_Click);
            // 
            // FT_selector
            // 
            this.FT_selector.Location = new System.Drawing.Point(119, 201);
            this.FT_selector.Name = "FT_selector";
            this.FT_selector.Size = new System.Drawing.Size(209, 55);
            this.FT_selector.TabIndex = 7;
            this.FT_selector.Text = "Select PC2Pi_FT Directory";
            this.FT_selector.UseVisualStyleBackColor = true;
            this.FT_selector.Click += new System.EventHandler(this.FT_selector_Click);
            // 
            // FT_Text
            // 
            this.FT_Text.Location = new System.Drawing.Point(344, 218);
            this.FT_Text.Name = "FT_Text";
            this.FT_Text.Size = new System.Drawing.Size(627, 25);
            this.FT_Text.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("SimSun", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(675, 316);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(277, 40);
            this.label1.TabIndex = 9;
            this.label1.Text = "File Transfer";
            // 
            // PC2Pi_FT
            // 
            this.PC2Pi_FT.Font = new System.Drawing.Font("SimSun", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.PC2Pi_FT.Location = new System.Drawing.Point(682, 663);
            this.PC2Pi_FT.Name = "PC2Pi_FT";
            this.PC2Pi_FT.Size = new System.Drawing.Size(276, 91);
            this.PC2Pi_FT.TabIndex = 8;
            this.PC2Pi_FT.Text = "Start";
            this.PC2Pi_FT.UseVisualStyleBackColor = true;
            this.PC2Pi_FT.Click += new System.EventHandler(this.PC2Pi_FT_Click);
            // 
            // shotsUp
            // 
            this.shotsUp.Image = global::OLED.Properties.Resources.Collapse_Icon_20px;
            this.shotsUp.Location = new System.Drawing.Point(369, 384);
            this.shotsUp.Name = "shotsUp";
            this.shotsUp.Size = new System.Drawing.Size(46, 39);
            this.shotsUp.TabIndex = 18;
            this.shotsUp.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.shotsUp.UseVisualStyleBackColor = true;
            this.shotsUp.Click += new System.EventHandler(this.shotsUp_Click);
            // 
            // shotsDown
            // 
            this.shotsDown.Image = global::OLED.Properties.Resources.Expand_Icon_20px;
            this.shotsDown.Location = new System.Drawing.Point(369, 421);
            this.shotsDown.Name = "shotsDown";
            this.shotsDown.Size = new System.Drawing.Size(46, 39);
            this.shotsDown.TabIndex = 21;
            this.shotsDown.UseVisualStyleBackColor = true;
            this.shotsDown.Click += new System.EventHandler(this.shotsDown_Click);
            // 
            // totalShots_text
            // 
            this.totalShots_text.Font = new System.Drawing.Font("SimSun", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.totalShots_text.Location = new System.Drawing.Point(268, 384);
            this.totalShots_text.MinimumSize = new System.Drawing.Size(46, 39);
            this.totalShots_text.Name = "totalShots_text";
            this.totalShots_text.Size = new System.Drawing.Size(103, 76);
            this.totalShots_text.TabIndex = 22;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("SimSun", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(69, 404);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(193, 30);
            this.label2.TabIndex = 23;
            this.label2.Text = "Total Shots:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("SimSun", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(39, 510);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(223, 30);
            this.label3.TabIndex = 27;
            this.label3.Text = "Time Interval:";
            // 
            // timeInterval_text
            // 
            this.timeInterval_text.Font = new System.Drawing.Font("SimSun", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.timeInterval_text.Location = new System.Drawing.Point(268, 490);
            this.timeInterval_text.MinimumSize = new System.Drawing.Size(46, 39);
            this.timeInterval_text.Name = "timeInterval_text";
            this.timeInterval_text.Size = new System.Drawing.Size(103, 76);
            this.timeInterval_text.TabIndex = 26;
            // 
            // intervalDown
            // 
            this.intervalDown.Image = global::OLED.Properties.Resources.Expand_Icon_20px;
            this.intervalDown.Location = new System.Drawing.Point(369, 527);
            this.intervalDown.Name = "intervalDown";
            this.intervalDown.Size = new System.Drawing.Size(46, 39);
            this.intervalDown.TabIndex = 25;
            this.intervalDown.UseVisualStyleBackColor = true;
            this.intervalDown.Click += new System.EventHandler(this.intervalDown_Click);
            // 
            // intervalUp
            // 
            this.intervalUp.Image = global::OLED.Properties.Resources.Collapse_Icon_20px;
            this.intervalUp.Location = new System.Drawing.Point(369, 490);
            this.intervalUp.Name = "intervalUp";
            this.intervalUp.Size = new System.Drawing.Size(46, 39);
            this.intervalUp.TabIndex = 24;
            this.intervalUp.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.intervalUp.UseVisualStyleBackColor = true;
            this.intervalUp.Click += new System.EventHandler(this.intervalUp_Click);
            // 
            // splitter1
            // 
            this.splitter1.Location = new System.Drawing.Point(0, 0);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(3, 806);
            this.splitter1.TabIndex = 28;
            this.splitter1.TabStop = false;
            // 
            // save_selector
            // 
            this.save_selector.Location = new System.Drawing.Point(467, 503);
            this.save_selector.Name = "save_selector";
            this.save_selector.Size = new System.Drawing.Size(206, 55);
            this.save_selector.TabIndex = 30;
            this.save_selector.Text = "Select Folder to be saved";
            this.save_selector.UseVisualStyleBackColor = true;
            this.save_selector.Click += new System.EventHandler(this.save_selector_Click);
            // 
            // Save_Text
            // 
            this.Save_Text.Location = new System.Drawing.Point(692, 520);
            this.Save_Text.Name = "Save_Text";
            this.Save_Text.Size = new System.Drawing.Size(372, 25);
            this.Save_Text.TabIndex = 29;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("SimSun", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(474, 421);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(199, 20);
            this.label4.TabIndex = 34;
            this.label4.Text = "Select today\'s date";
            // 
            // yearText
            // 
            this.yearText.Font = new System.Drawing.Font("SimSun", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.yearText.Location = new System.Drawing.Point(715, 409);
            this.yearText.MinimumSize = new System.Drawing.Size(46, 39);
            this.yearText.Name = "yearText";
            this.yearText.Size = new System.Drawing.Size(92, 42);
            this.yearText.TabIndex = 33;
            // 
            // yearDown
            // 
            this.yearDown.Image = global::OLED.Properties.Resources.Expand_Icon_20px;
            this.yearDown.Location = new System.Drawing.Point(804, 429);
            this.yearDown.Name = "yearDown";
            this.yearDown.Size = new System.Drawing.Size(22, 23);
            this.yearDown.TabIndex = 32;
            this.yearDown.UseVisualStyleBackColor = true;
            this.yearDown.Click += new System.EventHandler(this.yearDown_Click);
            // 
            // yearUp
            // 
            this.yearUp.Image = global::OLED.Properties.Resources.Collapse_Icon_20px;
            this.yearUp.Location = new System.Drawing.Point(804, 409);
            this.yearUp.Name = "yearUp";
            this.yearUp.Size = new System.Drawing.Size(22, 23);
            this.yearUp.TabIndex = 31;
            this.yearUp.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.yearUp.UseVisualStyleBackColor = true;
            this.yearUp.Click += new System.EventHandler(this.yearUp_Click);
            // 
            // monthText
            // 
            this.monthText.Font = new System.Drawing.Font("SimSun", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.monthText.Location = new System.Drawing.Point(823, 409);
            this.monthText.MinimumSize = new System.Drawing.Size(46, 39);
            this.monthText.Name = "monthText";
            this.monthText.Size = new System.Drawing.Size(51, 42);
            this.monthText.TabIndex = 37;
            // 
            // monthDown
            // 
            this.monthDown.Image = global::OLED.Properties.Resources.Expand_Icon_20px;
            this.monthDown.Location = new System.Drawing.Point(871, 429);
            this.monthDown.Name = "monthDown";
            this.monthDown.Size = new System.Drawing.Size(22, 23);
            this.monthDown.TabIndex = 36;
            this.monthDown.UseVisualStyleBackColor = true;
            this.monthDown.Click += new System.EventHandler(this.monthDown_Click);
            // 
            // monthUp
            // 
            this.monthUp.Image = global::OLED.Properties.Resources.Collapse_Icon_20px;
            this.monthUp.Location = new System.Drawing.Point(871, 409);
            this.monthUp.Name = "monthUp";
            this.monthUp.Size = new System.Drawing.Size(22, 23);
            this.monthUp.TabIndex = 35;
            this.monthUp.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.monthUp.UseVisualStyleBackColor = true;
            this.monthUp.Click += new System.EventHandler(this.monthUp_Click);
            // 
            // dayText
            // 
            this.dayText.Font = new System.Drawing.Font("SimSun", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.dayText.Location = new System.Drawing.Point(890, 409);
            this.dayText.MinimumSize = new System.Drawing.Size(46, 39);
            this.dayText.Name = "dayText";
            this.dayText.Size = new System.Drawing.Size(51, 42);
            this.dayText.TabIndex = 40;
            // 
            // dayDown
            // 
            this.dayDown.Image = global::OLED.Properties.Resources.Expand_Icon_20px;
            this.dayDown.Location = new System.Drawing.Point(938, 429);
            this.dayDown.Name = "dayDown";
            this.dayDown.Size = new System.Drawing.Size(22, 23);
            this.dayDown.TabIndex = 39;
            this.dayDown.UseVisualStyleBackColor = true;
            this.dayDown.Click += new System.EventHandler(this.dayDown_Click);
            // 
            // dayUp
            // 
            this.dayUp.Image = global::OLED.Properties.Resources.Collapse_Icon_20px;
            this.dayUp.Location = new System.Drawing.Point(938, 409);
            this.dayUp.Name = "dayUp";
            this.dayUp.Size = new System.Drawing.Size(22, 23);
            this.dayUp.TabIndex = 38;
            this.dayUp.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.dayUp.UseVisualStyleBackColor = true;
            this.dayUp.Click += new System.EventHandler(this.dayUp_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1080, 806);
            this.Controls.Add(this.dayText);
            this.Controls.Add(this.dayDown);
            this.Controls.Add(this.dayUp);
            this.Controls.Add(this.monthText);
            this.Controls.Add(this.monthDown);
            this.Controls.Add(this.monthUp);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.yearText);
            this.Controls.Add(this.yearDown);
            this.Controls.Add(this.yearUp);
            this.Controls.Add(this.save_selector);
            this.Controls.Add(this.Save_Text);
            this.Controls.Add(this.splitter1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.timeInterval_text);
            this.Controls.Add(this.intervalDown);
            this.Controls.Add(this.intervalUp);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.totalShots_text);
            this.Controls.Add(this.shotsDown);
            this.Controls.Add(this.shotsUp);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.PC2Pi_FT);
            this.Controls.Add(this.FT_selector);
            this.Controls.Add(this.FT_Text);
            this.Controls.Add(this.CC_selector);
            this.Controls.Add(this.CC_text);
            this.Controls.Add(this.python_text);
            this.Controls.Add(this.python_select);
            this.Controls.Add(this.CameraCtrlLabel);
            this.Controls.Add(this.PC2Pi_CC);
            this.Name = "Form3";
            this.Text = "Form3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button PC2Pi_CC;
        private System.Windows.Forms.Label CameraCtrlLabel;
        private System.Windows.Forms.Button python_select;
        private System.Windows.Forms.TextBox python_text;
        private System.Windows.Forms.TextBox CC_text;
        private System.Windows.Forms.Button CC_selector;
        private System.Windows.Forms.Button FT_selector;
        private System.Windows.Forms.TextBox FT_Text;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button PC2Pi_FT;
        private System.Windows.Forms.Button shotsUp;
        private System.Windows.Forms.Button shotsDown;
        private System.Windows.Forms.TextBox totalShots_text;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox timeInterval_text;
        private System.Windows.Forms.Button intervalDown;
        private System.Windows.Forms.Button intervalUp;
        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.Button save_selector;
        private System.Windows.Forms.TextBox Save_Text;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox yearText;
        private System.Windows.Forms.Button yearDown;
        private System.Windows.Forms.Button yearUp;
        private System.Windows.Forms.TextBox monthText;
        private System.Windows.Forms.Button monthDown;
        private System.Windows.Forms.Button monthUp;
        private System.Windows.Forms.TextBox dayText;
        private System.Windows.Forms.Button dayDown;
        private System.Windows.Forms.Button dayUp;
    }
}