﻿/*
 * File:    Form3
 * 
 * Author:  Shuyang Zhang
 * Date:    2020-2021
 * Project: Lensless Imaging
 * 
 * Summary of the file:
 * 
 *  Handles all the interactive functions for Form3.
 *  Main functions include sending Raspberry Pi commends
 *  to take time-lapsed photos and retrive photos from Pi.
 *  
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;

namespace OLED
{
    public partial class Form3 : Form
    {
        private string python_path = "";
        private string CC_path = ""; 
        private string FT_path = "";
        private string save_path = "";
        private int totalShots = 1;
        private int timeInterval = 60;
        private int year = 2021;
        private int month = 1;
        private int day = 1;

        public Form3()
        {
            InitializeComponent();
            totalShots_text.Text = totalShots.ToString();
            timeInterval_text.Text = timeInterval.ToString();
            yearText.Text = year.ToString();
            monthText.Text = month.ToString();
            dayText.Text = day.ToString();
        }

        private void python_select_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog pythonSelector = new FolderBrowserDialog();
            pythonSelector.RootFolder = Environment.SpecialFolder.Desktop;
            pythonSelector.Description = "Select the python.exe file";
            pythonSelector.ShowNewFolderButton = false;

            if (pythonSelector.ShowDialog() == DialogResult.OK)
            {
                python_text.Text = pythonSelector.SelectedPath + @"\python.exe";
                python_path = pythonSelector.SelectedPath + @"\python.exe";
            }

        }

        private void CC_selector_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog CCSelector = new FolderBrowserDialog();
            CCSelector.RootFolder = Environment.SpecialFolder.Desktop;
            CCSelector.Description = "Select the PC2Pi_CC.py file";
            CCSelector.ShowNewFolderButton = false;

            if (CCSelector.ShowDialog() == DialogResult.OK)
            {
                CC_text.Text = CCSelector.SelectedPath + @"\PC2Pi_CC.py";
                CC_path = CCSelector.SelectedPath + @"\PC2Pi_CC.py";
            }
        }

        private void FT_selector_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog FTSelector = new FolderBrowserDialog();
            FTSelector.RootFolder = Environment.SpecialFolder.Desktop;
            FTSelector.Description = "Select the PC2Pi_FT.py file";
            FTSelector.ShowNewFolderButton = false;

            if (FTSelector.ShowDialog() == DialogResult.OK)
            {
                FT_Text.Text = FTSelector.SelectedPath + @"\PC2Pi_FT.py";
                FT_path = FTSelector.SelectedPath + @"\PC2Pi_FT.py";
            }
        }

        private void save_selector_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog SaveSelector = new FolderBrowserDialog();
            SaveSelector.RootFolder = Environment.SpecialFolder.Desktop;
            SaveSelector.Description = "Select the folder you want to save the images to";
            SaveSelector.ShowNewFolderButton = false;

            if (SaveSelector.ShowDialog() == DialogResult.OK)
            {
                Save_Text.Text = SaveSelector.SelectedPath;
                save_path = SaveSelector.SelectedPath;
            }
        }

        private void PC2Pi_CC_Click(object sender, EventArgs e)
        {
            try
            {
                string CC_args = String.Format("{0} {1} {2}", CC_path, totalShots, timeInterval);
                Process CC = new Process();
                CC.StartInfo = new ProcessStartInfo
                {
                    WindowStyle = ProcessWindowStyle.Hidden,
                    FileName = python_path,
                    Arguments = CC_args,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    UseShellExecute = false
                };
                CC.Start();
            }

            catch
            {
                MessageBox.Show("Invalid file path. Please try again.", "Error in path selection");
                return;
            }
        }

        private void PC2Pi_FT_Click(object sender, EventArgs e)
        {
            try
            {
                String formatedDay = formatDate(year, month, day);
                string FT_args = String.Format("{0} {1} {2}", FT_path, save_path, formatedDay);
                Process FT = new Process();

                FT.StartInfo = new ProcessStartInfo
                {
                    WindowStyle = ProcessWindowStyle.Hidden,
                    FileName = python_path,
                    Arguments = FT_args,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    UseShellExecute = false
                };
                FT.Start();
            }
            catch
            {
                MessageBox.Show("Invalid file path. Please try again.", "Error in path selection");
                return;
            }

        }

        private string formatDate(int year, int month, int day)
        {
            string date = "20210101";
            string formatYear = year.ToString();
            string formatMonth = month.ToString();
            string formatDay = day.ToString();

            if (month < 10)
            {
                formatMonth = formatMonth.Insert(0, "0");
            }
            if (day < 10)
            {
                formatDay = formatDay.Insert(0, "0");
            }

            date = String.Format("{0}{1}{2}", formatYear, formatMonth, formatDay);
            return date;
        }

        private void shotsUp_Click(object sender, EventArgs e)
        {
            totalShots = totalShots + 1;
            totalShots_text.Text = totalShots.ToString();
        }

        private void shotsDown_Click(object sender, EventArgs e)
        {
            if (totalShots > 1)
            {
                totalShots = totalShots - 1;
                totalShots_text.Text = totalShots.ToString();
            }
        }

        private void intervalUp_Click(object sender, EventArgs e)
        {
            timeInterval = timeInterval + 15;
            timeInterval_text.Text = timeInterval.ToString();
        }

        private void intervalDown_Click(object sender, EventArgs e)
        {
            if (timeInterval > 60)
            {
                timeInterval = timeInterval - 15;
                timeInterval_text.Text = timeInterval.ToString();
            }
        }

        private void yearUp_Click(object sender, EventArgs e)
        {
            year = year + 1;
            yearText.Text = year.ToString();
        }

        private void yearDown_Click(object sender, EventArgs e)
        {
            year = year - 1;
            yearText.Text = year.ToString();
        }

        private void monthUp_Click(object sender, EventArgs e)
        {
            if (month < 12)
            {
                month = month + 1;
                monthText.Text = month.ToString();
            }
        }

        private void monthDown_Click(object sender, EventArgs e)
        {
            if (month > 1)
            {
                month = month - 1;
                monthText.Text = month.ToString();
            }
        }

        private void dayUp_Click(object sender, EventArgs e)
        {
            if (day < 31)
            {
                day = day + 1;
                dayText.Text = day.ToString();
            }
        }

        private void dayDown_Click(object sender, EventArgs e)
        {
            if (day > 1)
            {
                day = day - 1;
                dayText.Text = day.ToString();
            }
        }

        
    }
}
