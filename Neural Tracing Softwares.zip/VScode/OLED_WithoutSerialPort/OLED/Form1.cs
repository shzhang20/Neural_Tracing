﻿/*
 * File:    Form1
 * 
 * Author:  Shuyang Zhang
 * Date:    2020-2021
 * Project: Lensless Imaging
 * Notice:  Testing version, serial open commend disabled
 * 
 * Summary of the file:
 * 
 *  Handles all the interactive functions for Form1.
 *  Main functions include showing a small display of what 
 *  the OLED panel should look like based on previous commends,
 *  allowing users to access Form2 and Form3 and process the 
 *  outputs, allowing users to clean the display panel.
 *  
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OLED
{
    public partial class Form1 : Form
    {
        //Initialize the pixel dimensions (depends on the actual display)
        static int nX = 128;
        static int nY = 96;

        //Initialize the GridBoard object, a digital matrix holds the display information
        //0 = Black; 1 = Red; 2 = Green; 3 = Blue
        int[,] GridBoard = new int[nX, nY];

        //Initialize the bitmap that show the display panel
        static int bmpMultiplier = 2;
        Bitmap bmp = new Bitmap(nX * bmpMultiplier, nY * bmpMultiplier);

        //Initialize the pixel color
        String ColorCode = "R";
        Color PaintColor = Color.Red;
        int ColorValue = 1;
        
        //Constructor
        public Form1()
        {
            InitializeComponent();
            //serialPort1.Open();
            MapPanel.BackgroundImage = bmp;
            this.GridUpdate();
            redToolStripMenuItem.Checked = true;
        }

       

        //Methods:

        //Update the bitmap based on rectangle shape
        private void RectPaint(int x_dim, int y_dim, int width, int height, Color color)
        {
            for (int w = 0; w < width; w++)
            {
                for (int h = 0; h < height; h++)
                {
                    this.bmp.SetPixel(x_dim * bmpMultiplier + w * bmpMultiplier, y_dim * bmpMultiplier + h * bmpMultiplier, color);
                }
            }
            MapPanel.Refresh();

        }

        //Update the bitmap based on the GridBoard values
        private void GridUpdate()
        {
            for (int x = 0; x < nX; x++)
            {
                for (int y = 0; y < nY; y++)
                {
                    if (this.GridBoard[x, y] == 1)
                    {
                        this.bmp.SetPixel(x * bmpMultiplier, y * bmpMultiplier, Color.Red);
                    }

                    else if (this.GridBoard[x, y] == 2)
                    {
                        this.bmp.SetPixel(x * bmpMultiplier, y * bmpMultiplier, Color.Green);
                    }

                    else if (this.GridBoard[x, y] == 3)
                    {
                        this.bmp.SetPixel(x * bmpMultiplier, y * bmpMultiplier, Color.Blue);
                    }

                    else
                    {
                        this.bmp.SetPixel(x * bmpMultiplier, y * bmpMultiplier, Color.Black);
                    }

                }
            }
            MapPanel.Refresh();
        }

        //Update the current GridBoard based on the user inputs in Form2 and sends display
        //commends to arduino. 
        //Will not be used directly in Form1, but will be used in Form2.
        public void DataSendingHandler(int[,] Gridboard,  List<String> commands)
        {
            for (int i = 0 ; i < nX; i++)
            {
                for (int j = 0 ; j < nY; j++)
                {
                    this.GridBoard[i, j] = Gridboard[i,j];
                }
            }

            //for (int c = 0; c < commands.count; c++)
            //{
            //    serialport1.write(commands[c]);
            //}
            this.GridUpdate();
        }

        //EventHandlers:

        //Only used when user is manually entering the coordinates of the rectangle shape
        private void Set_Click(object sender, EventArgs e)
        {
            int XStart = int.Parse(xValue.Text);
            int YStart = int.Parse(yValue.Text);
            int Width = int.Parse(width.Text);
            int Height = int.Parse(height.Text);

            for (int i = 0; i < Width; i++)
            {
                for (int j = 0; j < Height; j++)
                {
                    this.GridBoard[XStart + i, YStart + j] = ColorValue;
                }
            }


            //serialPort1.Write("#R" + xValue.Text + yValue.Text + width.Text + height.Text + ColorCode + "\n");
            RectPaint(XStart, YStart, Width, Height, PaintColor);
        }

        //Clear the screen
        private void ClearScr_Click(object sender, EventArgs e)
        {
            //serialPort1.Write("#C\n");
            GridBoard = new int[nX, nY];
            this.GridUpdate();
        }

        //Send commands to the Arduino to do a ResTest of the OLED 
        private void ResTest_Click(object sender, EventArgs e)
        {
            serialPort1.Write("#T\n");
            int test_count = 1;
            for (int i = 0; i < nX; i = i + 2 * test_count)
            {
                for (int t = 0; t < test_count; t++)
                {
                    for (int j = 0; j < nY; j++)
                    {
                        GridBoard[i+t, j] = 1;
                    }
                }
                test_count = test_count + 1;
            }
            this.GridUpdate();
        }

        //Initialize the Form2
        private void Preview_Click(object sender, EventArgs e)
        {
            Form2 frm2 = new Form2(this, this.GridBoard);
            frm2.ShowDialog();
        }


        //Choose different colors 
        private void redToolStripMenuItem_Click(object sender, EventArgs e)
        {
            greenToolStripMenuItem.Checked = false;
            blueToolStripMenuItem.Checked = false;
            redToolStripMenuItem.Checked = true;
            ColorCode = "R";                             
            ColorValue = 1;
            PaintColor = Color.Red;
        }

        private void greenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            greenToolStripMenuItem.Checked = true;
            blueToolStripMenuItem.Checked = false;
            redToolStripMenuItem.Checked = false;
            ColorCode = "G";
            ColorValue = 2;
            PaintColor = Color.Green;
        }

        private void blueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            greenToolStripMenuItem.Checked = false;
            blueToolStripMenuItem.Checked = true;
            redToolStripMenuItem.Checked = false;
            ColorCode = "B";
            ColorValue = 3;
            PaintColor = Color.Blue;
        }


        //Initialize Form3
        private void Camera_Module_Click(object sender, EventArgs e)
        {
            Form3 frm3 = new Form3();
            frm3.ShowDialog();
        }
    }
}
