import sys
import subprocess

totalShots = sys.argv[1]
interval = sys.argv[2]

# Reminder: change the ip address and password to yours.
subprocess.run(["plink", "-no-antispoof", "pi@169.254.20.92", "-pw", "password",
                "python3", "/home/pi/Desktop/gphoto/imageCapture.py", totalShots,
                interval], stdout=subprocess.PIPE)

